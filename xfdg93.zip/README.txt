README!

Instructions!

First install all requirements by running (in a shell with python corectly installed):

python -r requirements.txt

Then start the nameserver with:

pyro4-ns

then start the front end with:

python frontend.py

and a number of backends with:

python backend.py

all in different shells.

external libraries used are Pyro4 and requests

external services used are the postcodes.io api for validating postcodes
